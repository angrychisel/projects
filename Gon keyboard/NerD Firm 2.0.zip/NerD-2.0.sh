#!/bin/sh
FILENAME="NerD-2.0.hex"
if [ -n "${FILENAME}" -a -f "${FILENAME}" ]
then
    ./NerD_downloader -f "${FILENAME}"
fi
