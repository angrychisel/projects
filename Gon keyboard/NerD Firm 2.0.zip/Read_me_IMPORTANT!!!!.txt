0. Do not down-grade your Firmware!


1. Plug only one NerD to your computer. Do not connect via USB HUB!!!!


2. Run "NerD_FirmUp.bat" and wait. If you see "Success!" ,all finished.


3. If you fail, follow these steps.

In case, the Indicator LED is blinking, run "NerD_FirmUp.bat" again and wait. If you see "Success!" ,all finished.

In case you have USB Only PCB and you don't see the indicator blinking, 
Disconnect your NerD from the computer, keep pressing ESC and connect to the computer, release ESC when you see the Indicator LED blinks.
Run "NerD_FirmUp.bat" and wait. If you see "Success!", all finished.

In case you have USB/Wireless Combo PCB and you don't see the indicator blinking, 
Do not disconnect the KBD from the computer but keep pressing ESC and order "KBD Reset"(This instruction can be ordered by Fn2+R if you didn't change the default keymap.)
Then the KBD will go into Bootloader mode. Now run "NerD_FirmUp.bat" again and wait. If you see "Success!", all finished.